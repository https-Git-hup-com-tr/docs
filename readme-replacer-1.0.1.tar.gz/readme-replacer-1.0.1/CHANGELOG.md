# Changelog v1

The Changelog of the major version 1 of Readme-Replacer GitHub Action.

Note that the displayed date is in the format `dd-mm-yyyy`

[Older changelogs](#older-changelogs)

## [v1.0.1]
> **Released:** `23-07-2021`

- Fix some bugs and improve error logging

[v1.0.1]: https://github.com/Readme-Workflows/readme-replacer/releases/tag/v1.0.1

## [v1.0.0]
> **Released:** `23-07-2021`

### Initial development of Readme Replacer

[v1.0.0]: https://github.com/Readme-Workflows/readme-replacer/releases/tag/v1.0.0

## Older changelogs
- No older changelogs
